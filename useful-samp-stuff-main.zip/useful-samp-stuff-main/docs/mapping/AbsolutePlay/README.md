_Welcome to the Mapping Toolkit wiki! The following description is in Russian, because it is the main language of the user base._

![LOGO](https://i.imgur.com/QvaGLC9.png)

* [Описание работы редактора карт на Absolute Play](https://github.com/ins1x/AbsEventHelper/wiki/%D0%9E%D0%BF%D0%B8%D1%81%D0%B0%D0%BD%D0%B8%D0%B5-%D1%80%D0%B0%D0%B1%D0%BE%D1%82%D1%8B-%D1%80%D0%B5%D0%B4%D0%B0%D0%BA%D1%82%D0%BE%D1%80%D0%B0-%D0%BA%D0%B0%D1%80%D1%82)

* [Редактор карт Absolute Play FAQ](https://github.com/ins1x/AbsEventHelper/wiki/%D0%A0%D0%B5%D0%B4%D0%B0%D0%BA%D1%82%D0%BE%D1%80-%D0%BA%D0%B0%D1%80%D1%82-FAQ)

* [Советы по маппингу на Absolute Play](https://github.com/ins1x/AbsEventHelper/wiki/%D0%A1%D0%BE%D0%B2%D0%B5%D1%82%D1%8B-%D0%BF%D0%BE-%D0%BC%D0%B0%D0%BF%D0%BF%D0%B8%D0%BD%D0%B3%D1%83)