[**[<<<Wiki]**](https://bitbucket.org/1nsanemapping/mappingwiki/wiki/Home)  


Функционал вы можете посмотреть тут: https://github.com/samp-incognito/sa...n/wiki/Natives
Обратные вызовы(паблики): https://github.com/samp-incognito/sa...wiki/Callbacks

Вводные понятия:
- Динамические объекты - это объекты, пикапы, иконки, 3D тексты, зоны, чекпоинты в целом.
- Динамические зоны - нефизическая (в игре) зона. Представляет собой только точки в пространстве.
- Стандартные - это функции плагина без постфикса Ex.


```
*** Streamer Plugin: Warning: Include file version (0x27002) does not match plugin version (0x27401) (script might need to be recompiled with the latest include file)
```

Тест оптимизации маппинга https://pastebin.com/Uve9nrwt
Streamer Plugin functions https://team.sa-mp.com/wiki/Streamer_Plugin.html
Документация по Incognito Streamer http://lightcode.ru/showthread.php?t=83042

[**[<<<Wiki]**](https://bitbucket.org/1nsanemapping/mappingwiki/wiki/Home)  