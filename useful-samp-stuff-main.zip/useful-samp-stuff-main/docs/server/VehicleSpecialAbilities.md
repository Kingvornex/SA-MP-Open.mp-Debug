# Vehicle Special Abilities and Features

Author: MadMax (ADRENALINEX Forum)
This could be useful for someone, maybe helps in making races/selecting vehicles for it, or just general having fun with SA.  
Anyway server got huge lags while I'm typing this, and I'm bored, so enjoy.  
  
List contains vehicles that got special abilities not common for every other, let me know if you got more.  
  
_italic_ - only for single player GTA SA  
  
_Ambulance - can be used for ambulance missions_  
**Andromada - along with other jets, fastest legit vehicle, can open rear gate and carry many people.  
AT-400 - along with other jets, fastest legit vehicle  
  
Baggage - along with Utility Van, can tow airport trailers  
Banshee - best accelerating road legal RWD (Rear Wheel Drive) car  
Bloodring Banger - got no doors or glass windows, you can hop in it through window frame  
BMX - jumps, that can be used to access intresting areas or low rooftops**  
_Broadway - can be used for pimp missions_  
_Brown Streak - along with Freight, can be used for train missions_  
**Bullet - lowest vehicle in game, along with Kart, can be used to access low areas (SF airport tollgate or LV rocks, fences etc), road legal RWD (Rear Wheel Drive) car**  
  
_Cabbie - along with Taxi, can be used for Taxi missions_  
**Caddy - almost always gets back on wheels after every flip**  
Clover - along with Previon and Feltzer is only car that has speedometer on dashboard  
_Coach - cops can't arrest you by opening doors_  
_Combine - can cut people_  
**Comet - if it is empty, player hops in it without opening doors  
Cop Cars - fastest 4 door car,** _can be used for police mission_  
**Cropduster - pressing 2 allows you to spray pesticides  
  
Dozer - movable scoop can be raised and lowered, can climb very step hills, got rear axle turning  
Dumper - movable bed  
  
Euros - only vehicle with glass sunroof  
  
FCR-900 - along with PCJ-600, fastest road legal bike  
Feltzer - along with Clover and Previon is only car that has speedometer on dashboard  
Firetruck - along with SWAT Tank, can 'fire' a stream of water,** _can be used for firetruck missions_  
**Flatbed - fastest normal truck in game  
Forklift - can be used to lift or raise crates, people or vehicles, got rear axle turning  
Freeway - can be used to access Area 69 military base**  
_Freight - along with Brown Streak, can be used for train missions_  
  
_Hotdog - you can buy hotdog from parked one_  
**Hotknife - only fully custom hotrod in game**  
**Hotring, Hotring A, Hotring B - the fastest RWD (Rear Wheel Drive) car**  
_HPV-1000 - can be used for police missions_  
**Hunter - fastest helicopter, fire rockets and gunfire,** _can be used for police missions_  
**Hydra - along with other jets, fastest legit vehicle, can move vertical or 'freeze' in air, fire rockets and flares  
  
Infernus - fastest car and legit land vehicle in game  
  
Kart - lowest vehicle in game, along with Bullet, can be used to access low areas (SF airport tollgate or LV rocks, fences etc)  
  
Leviathan - along with Sea Sparrow, can land on water  
  
Monster, Monster A, Monster B - along with Quad, doesn't slow down on railroads (can keep top speed, unlike mostly vehicles), wheels can't be popped, both axles turning  
Mountain Bike -  fastest bicycle  
  
NRG-500 - fastest bike, best accelerating and (with bugging) fastest land vehicle  
  
Packer - got movable ramp, can be used to access areas  
PCJ-600 - along with FCR-900, fastest road legal bike  
Premier - fastest normal 4 door car  
Previon - along with Clover and Feltzer is only car that has speedometer on dashboard  
  
Quad - along with Monsters, doesn't slow down on railroads (can keep top speed, unlike mostly vehicles)**  
  
_Ranger - can be used for police missions_  
**RC Bandit - along with RC Tiger, got no collision, making it 'ghost mode vehicle'  
RC Baron - aling with RC Goblin and RC Raider, can fly in unlyable for normal planes and helicopters, areas or heights (for example Liberty City)  
RC Goblin - aling with RC Baron and RC Raider, can fly in unlyable for normal planes and helicopters, areas or heights (for example Liberty City)  
RC Raider - aling with RC Baron and RC Goblin, can fly in unlyable for normal planes and helicopters, areas or heights (for example Liberty City)  
RC Tiger - along with RC Bandit, got no collision, making it 'ghost mode vehicle'  
Rhino - movable turret, can shot, wheels can't be popped,** _can be used for police missions_  
**Roadtrain - fastest rig truck  
Rustler - fastest proppeler plane, can shot  
  
Savanna - can perfrom wheelie stand, exhaust pipe is paintable when stock  
Sea Sparrow - along with Leviathan, can land on water, can shot  
Shamal - along with other jets, fastest legit vehicle  
Squalo - fastest boat and (with bugging) vehicle  
SWAT Tank - along with Firetruck, can 'fire' stream of water**  
  
_Taxi - along with Cabbie, can be used for Taxi missions_  
**Tornado - lowest suspension, can perform scrapping/dragging from rear  
Tow Truck - can tow vehicles  
Tractor - can tow trailers or vehicles  
Turismo - best accelerating car  
  
Utiliy Van - along with Baggage, can tow airport trailers  
  
Vortex - can be used in any area, land water and air gliding  
  
ZR-350 - headlights pop-up in night**  
    
---  

Also, somone requested list of vehicles with paintjobs, so:  
**Blade  
Broadway  
Camper\* - not tunable  
Elegy  
Flash  
Jester  
Remington  
Savanna  
Slamvan  
Stratum  
Sultan  
Tornado  
Uranus**  