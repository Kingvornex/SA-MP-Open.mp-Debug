a set of various ready-made [functions](https://sampwiki.blast.hk/wiki/Function) from my projects

forked from https://gist.github.com/ins1x