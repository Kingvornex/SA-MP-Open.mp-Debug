# valid-objects-models

IsValidObjectModel(modelid) Checks valid GTA:SA and SA:MP models.  
> NOTE: not the same as a function IsValidObject(objectid)  
This is not check if an object exists, check only a model is valid.  

# ugmp-objects-models

This include contains a list of [UG-MP](https://gtaundergroundmod.com/) objects in the format modelid - object name.  
This file does not add new objects, contain lists existing ones.  
The material presented is provided "as is" and has been published to facilitate the work.  

![UGMP_objects](https://i.imgur.com/WeQAEIw.jpeg)

All UG-MP objects on one page: https://i.imgur.com/OzQP4MQ.jpg  
Imgur Gallery: https://imgur.com/gallery/JvtNcZI  

More information on the official website  
This page contains all of the models UG-MP provides which aren't peds, vehicles, or weapons.  
https://gtaundergroundmod.com/pages/ug-mp/documentation/models/page-1  

>This is not an official UG-MP repository. Аuthor is not a member GTA: Underground team.
